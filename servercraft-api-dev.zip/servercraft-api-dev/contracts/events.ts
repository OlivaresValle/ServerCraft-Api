declare module '@ioc:Adonis/Core/Event' {
  interface EventsList {}
}
